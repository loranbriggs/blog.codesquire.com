﻿//
// MainPage.xaml.cpp
// Implementation of the MainPage class.
//

#include "pch.h"
#include "MainPage.xaml.h"

using namespace RandomCard;

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;
using namespace Windows::UI::Xaml::Media::Imaging;

String^ randomCard();

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

MainPage::MainPage()
{
	InitializeComponent();
}

/// <summary>
/// Invoked when this page is about to be displayed in a Frame.
/// </summary>
/// <param name="e">Event data that describes how this page was reached.  The Parameter
/// property is typically used to configure the page.</param>
void MainPage::OnNavigatedTo(NavigationEventArgs^ e)
{
	(void) e;	// Unused parameter
}


void RandomCard::MainPage::drawButton_Click(Platform::Object^ sender, Windows::UI::Xaml::RoutedEventArgs^ e)
{
	//BitmapImage[] cardImages = ref new BitmapImage[16];
  BitmapImage^ bmImage1 = ref new BitmapImage();
  BitmapImage^ bmImage2 = ref new BitmapImage();
	bmImage1->UriSource = ref new Uri( "ms-appx:/cards/" + randomCard() );
	bmImage2->UriSource = ref new Uri( "ms-appx:/cards/" + randomCard() );

	dealer1->Source = bmImage1;
	dealer2->Source = bmImage2;
}


String^ randomCard() {
  int random_integer = rand() % 52;

  switch ( random_integer ) {
    case 0:
        return "c1.png";
    case 1:
        return "c2.png";
    case 2:
        return "c3.png";
    case 3:
        return "c4.png";
    case 4:
        return "c5.png";
    case 5:
        return "c6.png";
    case 6:
        return "c7.png";
    case 7:
        return "c8.png";
    case 8:
        return "c9.png";
    case 9:
        return "c10.png";
    case 10:
        return "cj.png";
    case 11:
        return "cq.png";
    case 12:
        return "ck.png";
    case 13:
        return "d1.png";
    case 14:
        return "d2.png";
    case 15:
        return "d3.png";
    case 16:
        return "d4.png";
    case 17:
        return "d5.png";
    case 18:
        return "d6.png";
    case 19:
        return "d7.png";
    case 20:
        return "d8.png";
    case 21:
        return "d9.png";
    case 22:
        return "d10.png";
    case 23:
        return "dj.png";
    case 24:
        return "dq.png";
    case 25:
        return "dk.png";
    case 26:
        return "h1.png";
    case 27:
        return "h2.png";
    case 28:
        return "h3.png";
    case 29:
        return "h4.png";
    case 30:
        return "h5.png";
    case 31:
        return "h6.png";
    case 32:
        return "h7.png";
    case 33:
        return "h8.png";
    case 34:
        return "h9.png";
    case 35:
        return "h10.png";
    case 36:
        return "hj.png";
    case 37:
        return "hq.png";
    case 38:
        return "hk.png";
    case 39:
        return "s1.png";
    case 40:
        return "s2.png";
    case 41:
        return "s3.png";
    case 42:
        return "s4.png";
    case 43:
        return "s5.png";
    case 44:
        return "s6.png";
    case 45:
        return "s7.png";
    case 46:
        return "s8.png";
    case 47:
        return "s9.png";
    case 48:
        return "s10.png";
    case 49:
        return "sj.png";
    case 50:
        return "sq.png";
    case 51:
        return "sk.png";
    case 52:
        return "jb.png";
    case 53:
        return "jr.png";
  }

}
